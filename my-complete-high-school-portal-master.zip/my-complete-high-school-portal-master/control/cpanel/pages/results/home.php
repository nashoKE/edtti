<?php 
$title="Result management";




if (!defined('resultspage'))
{// if the user access this page directly, take his ass back to home 

header('Location: ../../../index.php?action=notauth');
exit;
}


?>

<iframe src="manage_results/db/index.php?setresult" width="100%" height="995" name="pageframes" border="0" frameborder="0">You need a valid/current browser to load thos page. use Google chrome. thanks </iframe> 


<BR />
<BR />
<BR />
<BR />
<BR />
<BR />
<BR />
<BR />
<BR />
<BR />

