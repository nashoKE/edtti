<?php 
$title="Main Config Under developmet";




if (!defined('MYSCHOOLAPPADMIN_CORE'))
{// if the user access this page directly, take his ass back to home 

header('Location: ../../../index.php?action=notauth');
exit;
}


?>
<div style="margin:12px auto; font-size:18px; font-weight:900; text-align:center; font-variant:small-caps">page under development will be done soon
<a href="modules?controller=home" class="btn btn-primary btn-sm"> <i class="icon icon-home"></i> You Might Want to go Home</a>
</div>



