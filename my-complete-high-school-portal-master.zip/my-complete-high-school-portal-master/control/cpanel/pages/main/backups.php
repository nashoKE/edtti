<?php 
$title="Backups";

if (!defined('MYSCHOOLAPPADMIN_CORE'))
{// if the user access this page directly, take his ass back to home 

header('Location: ../../../index.php?action=notauth');
exit;
}

?>

<div style="margin:12px auto; font-size:18px; font-weight:900; text-align:center; font-variant:small-caps">Back up is done automatic everyday
<a href="home" class="btn btn-primary btn-sm"> <i class="icon icon-home"></i> You Might Want to go the Dashboard</a>
</div>




