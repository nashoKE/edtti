<?php 
$title="Main Config Under developmet";

if (!defined('MYSCHOOLAPPADMIN_CORE'))
{// if the user access this page directly, take his ass back to home 

header('Location: ../../../index.php?action=notauth');
exit;
}

?>

<div style="margin-left:40px">page under development will be done soon</div>





