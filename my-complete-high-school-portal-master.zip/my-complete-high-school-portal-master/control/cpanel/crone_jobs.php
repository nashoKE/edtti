<?php

// this page is note included yet. include to home page
// restore session for current term
// delete used pins, pu in another table
 ?>

