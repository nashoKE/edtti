<div class="adminconfiginside">
<a href="fancyadmin/admin_exams_types.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload Exam Types Using Fancy Box Frame</a><br />
   
   <div align="center"><iframe align="middle" style="border:thin;" src="fancyadmin/admin_exams_types.php" width="80%" height="550"> </iframe></div>

 </div>
