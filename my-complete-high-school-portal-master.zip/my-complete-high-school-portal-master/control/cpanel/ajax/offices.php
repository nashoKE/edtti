<div class="adminconfiginside">
<a href="fancyadmin/health_codes.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload Offices Using Fancy Box Frame</a><br />
   
   <div align="center"><iframe align="middle" style="border:thin; min-width:360px; max-width:800px; width:100%;" src="fancyadmin/health_codes.php" height="700"> Your browser do not support Iframe, get a recomended browser</iframe></div>

   
   <br />   <br />
   <br />
   <br />

   
   </div>