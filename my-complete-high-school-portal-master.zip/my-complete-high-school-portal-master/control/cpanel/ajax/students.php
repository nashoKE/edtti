
<div class="box span67"> 
		Student Details Loaded Succesfully
				</div><!--/span-->