<div class="adminconfiginside">
<a href="fancyadmin/admin_ethnicity.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload Ethnicity Using Fancy Box Frame</a><br />
   
   <div align="center">
   <iframe align="middle" style="border:thin; background-color:F00; min-width:360px; max-width:800px; width:100%;" src="fancyadmin/admin_ethnicity.php" height="1180px">
   This Browser Is not Supported. Please Upgrade this Browser </iframe></div>

   
   <br />   <br />
   <br />
   <br />
</div> 