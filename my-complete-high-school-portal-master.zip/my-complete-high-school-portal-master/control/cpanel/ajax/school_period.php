<div class="admin_schoolperiods">
<a href="fancyadmin/admin_school_period.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload School Period Using Fancy Box Frame</a><br />
   
   <div align="center"><iframe align="middle" style="border:thin;" src="fancyadmin/admin_school_period.php" width="80%" height="850"> </iframe></div>

 </div>
