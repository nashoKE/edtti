
	<div class="adminconfiginside">
	<a href="fancyadmin/schoolname.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload School names Using Fancy Box Frame</a><br />
   
   <div align="center"><iframe align="middle" style="border:thin; min-width:360px; max-width:800px; width:100%;" src="fancyadmin/schoolname.php" height="300px"> </iframe></div>

   
   <br />   <br />
   <br />
   <br />

   
   </div>
