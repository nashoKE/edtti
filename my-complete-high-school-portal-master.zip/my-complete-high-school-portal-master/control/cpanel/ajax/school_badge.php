<div align="center">
<a href="fancyadmin/school_badge.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload School Badge Using Fancy Box Frame</a><br />

   <div align="center"><iframe align="middle" style="border:thin; min-width:360px; max-width:800px; width:100%;" src="fancyadmin/school_badge.php" height="500"> </iframe></div>
<br>
<br>
<div align="center">


<br></div>
