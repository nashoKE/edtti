
<script src="ajax/profile/magic.js"></script> <!-- load our javascript file -->

<div class="col-sm-6 col-sm-offset-3">

<h1>Profile details</h1>

<div class="alert alert-info">
			<button type="button" class="close" data-dismiss="alert">*</button>
			<strong>Heads up!</strong> To edit this Profile detail, do it from student demography
		</div>
<div class="alert alert-info">
			<button type="button" class="close" data-dismiss="alert">*</button>
			<strong>Heads up!</strong> To edit State of origin, login to student portal
		</div>
		
		<a href="students?page=home#console" target="_blank"><button>Launch student demography </button></a>

</div>

