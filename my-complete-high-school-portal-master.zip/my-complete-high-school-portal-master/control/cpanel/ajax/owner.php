<div id ='owner' style="align:centre;">Profile Settings for

<div id="proprietor1">PROPRIETOR </div>

<div id="proprietor1">PRINCIPAL </div>

<div id="proprietor1">DIRECTOR </div>
</div>