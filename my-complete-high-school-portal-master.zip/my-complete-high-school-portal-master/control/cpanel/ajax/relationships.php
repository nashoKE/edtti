<div class="adminconfiginside">
<a href="fancyadmin/admin_relations.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload Relationships Using Fancy Box Frame</a><br />
   
   <div align="center"><iframe align="middle" style="border:thin;" src="fancyadmin/admin_relations.php" width="60%" height="1180px"> </iframe></div>

   
   <br />   <br />
   <br />
   <br />

   
   </div>

