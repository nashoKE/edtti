
<div class="adminconfiginside">
<a href="fancyadmin/admin_titles.php" style="margin:10px 0" class="fancybox fancybox.iframe btn btn-default btn-sm">Reload Titles Using Fancy Box Frame</a><br />
  
   <div align="center"><iframe align="middle" style="border:thin; min-width:360px; max-width:800px; width:100%;" src="fancyadmin/admin_titles.php"  height="1180px"> </iframe></div>

   
   <br />   <br />
   <br />
   <br />

   
   </div>

