<!-- left menu starts -->
			<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						

												<li><a class="ajax-link" href="index"><i class="icon32 icon-blue icon-home"></i><span class="hidden-tablet"> Dashboard</span></a></li>

						<li class="nav-header hidden-tablet">Teachers</li>

						<li><a class="ajax-link" href="teachers?page=home"><i class="icon32 icon-orange icon-compose"></i><span class="hidden-tablet"> Edit Database</span></a></li>
					   <li><a class="ajax-link" href="teachers?page=home"><i class="icon32 icon-orange icon-profile"></i><span class="hidden-tablet"> Teacher Profiles</span></a></li>

	<li><a class="ajax-link" href="teachers?page=home"><i class="icon32 icon-orange icon-clock"></i><span class="hidden-tablet">Speaking Hours</span></a></li>
		<li><a class="ajax-link" href="teachers?page=home"><i class="icon32 icon-orange icon-calendar"></i><span class="hidden-tablet">Time Table</span></a></li>

			<li><a class="ajax-link" href="teachers?page=salaries&control=health#console"><i class="icon32 icon-orange icon-lightbulb"></i><span class="hidden-tablet">Salaries</span></a></li>
<li><a class="ajax-link" href="teachers?page=online_exams&control=discipline#console"><i class="icon32 icon-orange icon-web"></i><span class="hidden-tablet"> Online Exams</span></a></li>

	
					</ul>
				</div><!--/.well -->			<?php include("left_bar_module.php");?>
			</div><!--/span-->
			<!-- left menu ends -->
