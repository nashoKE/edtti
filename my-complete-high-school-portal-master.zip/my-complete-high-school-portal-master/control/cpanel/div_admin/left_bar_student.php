<!-- left menu starts -->
			<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						

												<li><a class="ajax-link" href="index"><i class="icon32 icon-color icon-home"></i><span class="hidden-tablet"> Dashboard</span></a></li>

						<li class="nav-header hidden-tablet">Students</li>

						<li><a class="ajax-link" href="students?page=home"><i class="icon icon-green icon-compose"></i><span class="hidden-tablet"> Edit Database</span></a></li>
					   <li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-contacts"></i><span class="hidden-tablet"> Manage Demography</span></a></li>

	<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-clock"></i><span class="hidden-tablet">Manage Attendance</span></a></li>
			<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-info"></i><span class="hidden-tablet">Manage Health</span></a></li>
<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-scissors"></i><span class="hidden-tablet"> Discipline Student</span></a></li>
	<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-doc"></i><span class="hidden-tablet"> Grades Reporting</span></a></li>
	<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-pdf"></i><span class="hidden-tablet"> Media Reporting</span></a></li>
<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-shuffle"></i><span class="hidden-tablet">Change Class</span></a></li>
						<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-lightbulb"></i><span class="hidden-tablet">School Fees</span></a></li>
						<li><a class="ajax-link" href="main?page=users"><i class="icon icon-green icon-book"></i><span class="hidden-tablet">Book orders</span></a></li>
						<li><a class="ajax-link" href="main?page=parent_child"><i class="icon icon-green icon-users"></i><span class="hidden-tablet">Set Parents</span></a></li>

					</ul>
				</div><!--/.well -->			<?php include("left_bar_module.php");?>
			</div><!--/span-->
			<!-- left menu ends -->
