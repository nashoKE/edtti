
		<?php // if(!isset($no_visible_elements) || !$no_visible_elements)	{ ?>
			<!-- content ends -->
			<!-- </div><!--/#content.span10-->
		<?php // } ?>
		<!-- </div><!--/fluid-row-->
		<?php // if(!isset($no_visible_elements) || !$no_visible_elements)	{ ?>
		<!--
		<hr>

		<div class="modal hide fade" id="myModal">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">×</button>
				<h3>Settings</h3>
			</div>
			<div class="modal-body">
				<p>Here settings can be configured nut not yet ready. Please wait for the next version.</p>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn" data-dismiss="modal">Close</a>
			</div>
		</div> 
		-->