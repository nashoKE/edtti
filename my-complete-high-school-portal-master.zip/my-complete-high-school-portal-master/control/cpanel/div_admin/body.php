<div class="box-content">
						<h1>SchoolApp <small> premium quality, responsive, multiple School management system(Creche,Nursery,Primary,Secondary,Tertiary)</small></h1>
						<p>It is light weight, support UBEB format and its all you want</p>
						<p><b>PUT ALERTS AND WARNING HERE FOR ADMIN AND TEACHERS</b></p>
						
						<p class="center">
							<a href="http://usman.it/free-responsive-admin-template" class="btn btn-large btn-primary"><i class="icon-chevron-left icon-white"></i> Back to article</a> 
							<a href="http://usman.it/free-responsive-admin-template" class="btn btn-large"><i class="icon-download-alt"></i> Download Page</a>
						</p>
						<div class="clearfix"></div>
					</div>