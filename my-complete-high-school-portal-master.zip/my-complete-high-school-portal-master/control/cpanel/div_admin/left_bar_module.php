
<div class="well nav-collapse sidebar-nav">
	Turn On/Off Strike<input data-no-uniform="true" type="checkbox" class="iphone-toggle">
</div><!--/.well -->
