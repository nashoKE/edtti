<div class="box-content">
		<h3>HyperSchool<sup>TM </sup><small> (Creche -> Nursery -> Primary ->Secondary -> Tertiary) Amazing School Software<i>.</i></small></h3>
		<div id="session" align="right"><strong>Current Session: <font color="#000066" size="+1">
		<?php echo $cyear;  ?></font>: <em> <?php echo $cterm;  ?> </em></strong></div>
		
		<p>	<?php include('div_general/admin_notify.php')?></p>
		<p>&nbsp;</p>
		<p class="center"> 
		<a href="main?page=switchterm" class="btn btn-large btn-primary"><i class="icon-chevron-left icon-white"></i> Switch Term</a> &nbsp;&nbsp;
			<a href="switch_session" class="btn btn-large btn-primary"><i class="icon-chevron-left icon-white"></i> Change Session</a> 
			<a href="#" title="Sorry, Manual is still under construction, need any help on how to use the portal, talk to us in live chat or quickly call 08066424512" target="_blank" class="btn btn-large"><i class="icon-download-alt"></i> Download Operation Manual</a> <a href="main?page=reports" target="" class="btn btn-large"><i class="icon-download-alt"></i> Download General Reports</a>
		</p>
		<div class="clearfix"></div>
</div>